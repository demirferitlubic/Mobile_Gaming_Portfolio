# Toon Blast — Crown Rush Optimization Case Study

**Independent Product Management Case Study | October 2026**

An independent product analysis exploring player engagement, monetization trade-offs, and experimentation opportunities within Toon Blast's Crown Rush mechanic.

## Project Overview

Crown Rush rewards consecutive level victories with increasingly powerful starting boosters. However, losing a level resets the accumulated advantages, potentially discouraging players from continuing.

This case study investigates whether a limited post-failure recovery feature, **Comeback Assist**, could improve retry behavior without negatively affecting monetization or gameplay balance.

## What This Project Covers

- **Gameplay Analysis:** Evaluation of Crown Rush mechanics, player motivation, and loss aversion.
- **Product Design:** Proposal of Comeback Assist and comparison with alternative solutions.
- **Opportunity Sizing:** Estimation of potential player reach and game-wide impact using hypothetical scenarios.
- **Monetization Analysis:** Assessment of booster consumption, extra-move purchases, and possible revenue cannibalization.
- **A/B Testing:** Triggered-randomization experiment design, KPI selection, and statistical power analysis.
- **Product Prioritization:** Definition of rollout criteria and conditions under which the feature should be deprioritized.

## Key Recommendation

The illustrative opportunity-sizing analysis suggests that Comeback Assist may have limited game-wide impact under the assumed eligibility and behavioral improvement rates.

Therefore, the feature should not be prioritized without first validating the affected player population and expected business value.

The goal of this project is to demonstrate a data-informed product decision-making process, rather than recommend a feature regardless of its economic value.


## Methodology

Independent gameplay observation, product hypothesis development, hypothetical scenario modeling, experiment design, and statistical power analysis.

**Disclaimer:** This project is independent and is not affiliated with or endorsed by Peak Games. No internal company data was used, and no live experiment was conducted.
